#include "config.h"
#include <pic18f4520.h>
#include "kernel.h"
#include "timer.h"
#include "bits.h"
#include "ssd.h"

//interrupt setup

void __interrupt ISR(void) {
    //TIMER0: Overflow
    if (bitTst(INTCON, 2)) {
        // 65535 = 2*10.000 = 10mS
        TMR0H = (45535 >> 8);
        TMR0L = (45535 & 0x00FF);

        KernelClock();

        //limpa a flag
        bitClr(INTCON, 2);
    }
}

char t1(void) {
    PORTD = PORTD + 1;
    return REPEAT;
}


void main(void) {
    process p1 = {t1, 100, 0};
    TRISD = 0x00;
    timerInit();



    kernelInit();
    kernelAddProc(&p1);

    //interrupt start
    bitClr(RCON, 7); // desabilita IPEN ( modo de compatibilidade )
    bitSet(INTCON, 5); // liga a interrup��o para o timer 0
    bitSet(INTCON, 7); // habilita todas as interrup��es globais
    bitSet(INTCON, 6); // habilita todas as interrup��es de perifericos


    kernelLoop();
}
